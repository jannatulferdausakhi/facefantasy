import React, { useState } from 'react';
import { Joystick as Lipstick, User, Menu, X, LogOut, ShoppingBag, Calendar, FileText, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';

export const Navbar: React.FC = () => {
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const location = useLocation();
  
  const toggleDrawer = () => setIsDrawerOpen(!isDrawerOpen);
  const closeDrawer = () => setIsDrawerOpen(false);

  const NavLink: React.FC<{ to: string; icon: React.ReactNode; label: string }> = ({ to, icon, label }) => {
    const isActive = location.pathname === to;
    return (
      <Link 
        to={to} 
        className={`
          flex items-center px-4 py-3 rounded-md transition-colors
          ${isActive 
            ? 'bg-purple-100 text-purple-700' 
            : 'text-gray-700 hover:bg-purple-50 hover:text-purple-600'}
        `}
        onClick={closeDrawer}
      >
        <span className="mr-3">{icon}</span>
        {label}
      </Link>
    );
  };

  return (
    <>
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center">
              <Lipstick className="text-purple-600 h-8 w-8 mr-2" />
              <span className="font-bold text-xl text-purple-700">YourFaceFantasy</span>
            </Link>
            
            <div className="flex items-center">
              {isAuthenticated ? (
                <>
                  <div className="hidden md:flex items-center space-x-4">
                    <Link to="/profile" className="flex items-center text-gray-700 hover:text-purple-600">
                      <span className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
                        {user?.avatar ? (
                          <img src={user.avatar} alt={user?.name} className="h-8 w-8 rounded-full" />
                        ) : (
                          <User className="h-4 w-4 text-purple-600" />
                        )}
                      </span>
                      <span className="ml-2 text-sm font-medium">{user?.name}</span>
                    </Link>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={logout}
                      className="text-gray-600"
                    >
                      <LogOut className="h-4 w-4 mr-1" />
                      Logout
                    </Button>
                  </div>
                  <button
                    className="p-2 rounded-md md:hidden text-gray-700 hover:text-purple-600 hover:bg-purple-50"
                    onClick={toggleDrawer}
                  >
                    <Menu className="h-6 w-6" />
                  </button>
                </>
              ) : (
                <div className="flex items-center space-x-2">
                  <Link to="/login">
                    <Button variant="outline" size="sm">
                      Login
                    </Button>
                  </Link>
                  <Link to="/signup">
                    <Button size="sm">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile drawer/sidebar */}
      {isAuthenticated && (
        <div 
          className={`
            fixed inset-0 z-40 transform transition-transform duration-300 ease-in-out
            ${isDrawerOpen ? 'translate-x-0' : '-translate-x-full'}
            md:hidden
          `}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={closeDrawer}></div>
          
          <div className="absolute top-0 left-0 h-full w-64 bg-white shadow-lg overflow-y-auto">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user?.name} className="h-8 w-8 rounded-full" />
                    ) : (
                      <User className="h-4 w-4 text-purple-600" />
                    )}
                  </span>
                  <span className="ml-2 font-medium">{user?.name}</span>
                </div>
                <button
                  className="p-1 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                  onClick={closeDrawer}
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <nav className="p-2 space-y-1">
              <NavLink to="/" icon={<Home className="h-5 w-5" />} label="Home" />
              <NavLink to="/appointments" icon={<Calendar className="h-5 w-5" />} label="Appointments" />
              <NavLink to="/skincare-tips" icon={<FileText className="h-5 w-5" />} label="Skincare Tips" />
              <NavLink to="/products" icon={<ShoppingBag className="h-5 w-5" />} label="Products" />
              
              {isAdmin && (
                <div className="pt-2 mt-2 border-t border-gray-200">
                  <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Admin
                  </div>
                  <NavLink to="/admin/products" icon={<ShoppingBag className="h-5 w-5" />} label="Manage Products" />
                  <NavLink to="/admin/beauticians" icon={<User className="h-5 w-5" />} label="Manage Beauticians" />
                </div>
              )}
            </nav>
            
            <div className="border-t border-gray-200 p-4">
              <Button fullWidth onClick={logout} variant="outline">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};