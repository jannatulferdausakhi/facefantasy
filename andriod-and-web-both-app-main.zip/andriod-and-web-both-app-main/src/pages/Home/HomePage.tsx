import React, { useState } from 'react';
import { ShoppingBag, Search, Heart, Calendar, Sparkles, Filter } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router-dom';
import { Product } from '../../types';

// Mock products data
const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Luminous Foundation',
    description: 'Long-lasting coverage with a natural finish',
    price: 35.99,
    image: 'https://images.pexels.com/photos/2693644/pexels-photo-2693644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Face',
  },
  {
    id: '2',
    name: 'Velvet Matte Lipstick',
    description: 'Rich color with a smooth matte finish',
    price: 24.99,
    image: 'https://images.pexels.com/photos/2533266/pexels-photo-2533266.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Lips',
  },
  {
    id: '3',
    name: 'Radiance Highlighter',
    description: 'Shimmering glow for a natural radiance',
    price: 28.99,
    image: 'https://images.pexels.com/photos/2697786/pexels-photo-2697786.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Face',
  },
  {
    id: '4',
    name: 'Volume Boost Mascara',
    description: 'Dramatic lashes with no clumping',
    price: 22.99,
    image: 'https://images.pexels.com/photos/2688991/pexels-photo-2688991.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Eyes',
  },
  {
    id: '5',
    name: 'Eyeshadow Palette - Summer',
    description: 'Vibrant colors for any occasion',
    price: 42.99,
    image: 'https://images.pexels.com/photos/2261614/pexels-photo-2261614.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Eyes',
  },
  {
    id: '6',
    name: 'Skincare Set - Hydration',
    description: 'Complete routine for dry skin',
    price: 64.99,
    image: 'https://images.pexels.com/photos/3321416/pexels-photo-3321416.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Skincare',
  },
];

export const HomePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  
  const categories = ['All', 'Face', 'Eyes', 'Lips', 'Skincare'];
  
  const filteredProducts = MOCK_PRODUCTS.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === null || activeCategory === 'All' || product.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen">
      {/* Hero banner */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-500 text-white py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl font-bold mb-4">Discover Your Beauty</h1>
              <p className="text-lg mb-6">
                Explore our collection of premium beauty products and services designed to enhance your natural beauty.
              </p>
              <div className="flex space-x-4">
                <Link to="/products">
                  <Button className="bg-white text-purple-600 hover:bg-gray-100">
                    <ShoppingBag className="h-5 w-5 mr-2" />
                    Shop Now
                  </Button>
                </Link>
                <Link to="/appointments">
                  <Button variant="outline" className="border-white text-white hover:bg-white/10">
                    <Calendar className="h-5 w-5 mr-2" />
                    Book Appointment
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img 
                src="https://images.pexels.com/photos/3373716/pexels-photo-3373716.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Beauty Products" 
                className="rounded-lg shadow-lg max-w-full h-auto max-h-80 object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Products section */}
      <div className="py-12 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 className="text-2xl font-bold mb-4 md:mb-0">Featured Products</h2>
            
            <div className="w-full md:w-auto flex items-center">
              <div className="relative flex-1 md:w-64">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
              <div className="ml-2">
                <button className="p-2 border border-gray-300 rounded-md hover:bg-gray-50">
                  <Filter className="h-5 w-5 text-gray-600" />
                </button>
              </div>
            </div>
          </div>
          
          {/* Categories */}
          <div className="flex overflow-x-auto pb-2 mb-6 space-x-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category === 'All' ? null : category)}
                className={`
                  px-4 py-2 rounded-full whitespace-nowrap
                  ${activeCategory === category || (category === 'All' && activeCategory === null)
                    ? 'bg-purple-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'}
                  transition-colors
                `}
              >
                {category}
              </button>
            ))}
          </div>
          
          {/* Products grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-lg overflow-hidden shadow-md transition-transform duration-300 hover:shadow-lg hover:-translate-y-1"
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <button className="h-8 w-8 rounded-full bg-white shadow flex items-center justify-center hover:bg-pink-50 transition-colors">
                      <Heart className="h-4 w-4 text-pink-500" />
                    </button>
                  </div>
                  {product.id === '1' && (
                    <div className="absolute top-2 left-2 bg-purple-600 text-white text-xs px-2 py-1 rounded-full flex items-center">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Best Seller
                    </div>
                  )}
                </div>
                
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                  <div className="flex justify-between items-center mt-4">
                    <span className="font-bold text-lg">${product.price.toFixed(2)}</span>
                    <Button size="sm">
                      <ShoppingBag className="h-4 w-4 mr-1" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No products found matching your search.</p>
              <Button variant="outline" onClick={() => { setSearchQuery(''); setActiveCategory(null); }}>
                Clear Filters
              </Button>
            </div>
          )}
          
          <div className="mt-8 text-center">
            <Link to="/products">
              <Button variant="outline">View All Products</Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Services promo */}
      <div className="py-12 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-4">Our Beauty Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Book an appointment with our professional beauticians for a personalized beauty experience.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-pink-50 p-6 rounded-lg text-center">
              <div className="h-14 w-14 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="h-6 w-6 text-pink-600" />
              </div>
              <h3 className="font-bold text-lg mb-2">Makeup Services</h3>
              <p className="text-gray-600 mb-4">
                Professional makeup application for special occasions and everyday looks.
              </p>
              <Link to="/appointments">
                <Button variant="outline" size="sm">Book Now</Button>
              </Link>
            </div>
            
            <div className="bg-purple-50 p-6 rounded-lg text-center">
              <div className="h-14 w-14 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                </svg>
              </div>
              <h3 className="font-bold text-lg mb-2">Skincare Treatments</h3>
              <p className="text-gray-600 mb-4">
                Rejuvenating facials and skincare treatments for a healthy glow.
              </p>
              <Link to="/appointments">
                <Button variant="outline" size="sm">Book Now</Button>
              </Link>
            </div>
            
            <div className="bg-pink-50 p-6 rounded-lg text-center">
              <div className="h-14 w-14 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-pink-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <h3 className="font-bold text-lg mb-2">Beauty Consultation</h3>
              <p className="text-gray-600 mb-4">
                Personalized advice to help you find the perfect beauty routine.
              </p>
              <Link to="/appointments">
                <Button variant="outline" size="sm">Book Now</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};