import React, { useState } from 'react';
import { Calendar, Clock, ArrowRight, Star, ChevronDown, ChevronUp, Gift } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Beautician, Service } from '../../types';

// Mock beauticians data
const MOCK_BEAUTICIANS: Beautician[] = [
  {
    id: '1',
    name: 'Emma Wilson',
    photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Makeup Artist',
    experience: '5 years',
    rating: 4.8,
    portfolio: [
      'https://images.pexels.com/photos/2681751/pexels-photo-2681751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2442898/pexels-photo-2442898.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3762423/pexels-photo-3762423.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '101', name: 'Bridal Makeup', description: 'Complete bridal makeup with touch-ups', price: 150, duration: '3 hours', image: 'https://images.pexels.com/photos/1741230/pexels-photo-1741230.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '102', name: 'Natural Everyday Look', description: 'Subtle makeup for daily wear', price: 65, duration: '45 minutes', image: 'https://images.pexels.com/photos/942317/pexels-photo-942317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-16', '2025-01-17', '2025-01-18', '2025-01-20']
  },
  {
    id: '2',
    name: 'Sophia Chen',
    photo: 'https://images.pexels.com/photos/3444087/pexels-photo-3444087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Skincare Specialist',
    experience: '7 years',
    rating: 4.9,
    portfolio: [
      'https://images.pexels.com/photos/3764013/pexels-photo-3764013.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3738353/pexels-photo-3738353.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3738352/pexels-photo-3738352.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '201', name: 'Deep Cleansing Facial', description: 'Thorough cleansing and extraction', price: 85, duration: '60 minutes', image: 'https://images.pexels.com/photos/3764012/pexels-photo-3764012.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '202', name: 'Anti-Aging Treatment', description: 'Premium facial with anti-aging benefits', price: 120, duration: '75 minutes', image: 'https://images.pexels.com/photos/3997387/pexels-photo-3997387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-16', '2025-01-19', '2025-01-20', '2025-01-21']
  },
  {
    id: '3',
    name: 'Olivia Martinez',
    photo: 'https://images.pexels.com/photos/1840608/pexels-photo-1840608.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Makeup & Hair Stylist',
    experience: '6 years',
    rating: 4.7,
    portfolio: [
      'https://images.pexels.com/photos/3097158/pexels-photo-3097158.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2816792/pexels-photo-2816792.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3810873/pexels-photo-3810873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '301', name: 'Makeup & Hair for Event', description: 'Full makeup and hairstyling', price: 110, duration: '90 minutes', image: 'https://images.pexels.com/photos/2811090/pexels-photo-2811090.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '302', name: 'Hair Styling Only', description: 'Professional hair styling', price: 50, duration: '45 minutes', image: 'https://images.pexels.com/photos/3993329/pexels-photo-3993329.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-17', '2025-01-18', '2025-01-21', '2025-01-22']
  },
];

const AVAILABLE_DATES = [
  '2025-01-15',
  '2025-01-16',
  '2025-01-17',
  '2025-01-18',
  '2025-01-19',
  '2025-01-20',
  '2025-01-21',
  '2025-01-22',
];

// Time slots
const TIME_SLOTS = [
  '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
  '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'
];

export const AppointmentPage: React.FC = () => {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedBeautician, setSelectedBeautician] = useState<Beautician | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [portfolioOpen, setPortfolioOpen] = useState<string | null>(null);
  
  // Filter beauticians by selected date
  const availableBeauticians = selectedDate 
    ? MOCK_BEAUTICIANS.filter(beautician => beautician.availability.includes(selectedDate))
    : [];

  const handleDateSelect = (date: string) => {
    setSelectedDate(date);
    setSelectedBeautician(null);
    setSelectedService(null);
    setSelectedTime(null);
    setStep(2);
  };

  const handleBeauticianSelect = (beautician: Beautician) => {
    setSelectedBeautician(beautician);
    setSelectedService(null);
    setSelectedTime(null);
    setStep(3);
  };

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
    setSelectedTime(null);
    setStep(4);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep(5);
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const togglePortfolio = (beauticianId: string) => {
    if (portfolioOpen === beauticianId) {
      setPortfolioOpen(null);
    } else {
      setPortfolioOpen(beauticianId);
    }
  };

  const renderStepIndicator = () => {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {[1, 2, 3, 4, 5].map((stepNumber) => (
            <div key={stepNumber} className="flex flex-col items-center">
              <div 
                className={`h-10 w-10 rounded-full flex items-center justify-center
                  ${step === stepNumber 
                    ? 'bg-purple-600 text-white' 
                    : step > stepNumber 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-500'}`}
              >
                {step > stepNumber ? (
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  stepNumber
                )}
              </div>
              <span className="text-xs mt-2">
                {stepNumber === 1 && "Date"}
                {stepNumber === 2 && "Beautician"}
                {stepNumber === 3 && "Service"}
                {stepNumber === 4 && "Time"}
                {stepNumber === 5 && "Confirm"}
              </span>
            </div>
          ))}
        </div>
        <div className="relative flex items-center justify-between mt-2">
          <div className="absolute left-0 right-0 h-1 bg-gray-200">
            <div 
              className="absolute h-1 bg-purple-600 transition-all duration-500" 
              style={{ width: `${(step - 1) * 25}%` }}
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen py-12 px-4 bg-gray-50">
      <div className="container mx-auto max-w-4xl">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-purple-600 p-6 text-white">
            <h1 className="text-2xl font-bold">Book Your Beauty Appointment</h1>
            <p className="text-purple-100">Schedule a session with our professional beauticians</p>
          </div>
          
          <div className="p-6">
            {renderStepIndicator()}
            
            {step === 1 && (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold mb-6 flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-purple-600" />
                  Select a Date
                </h2>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {AVAILABLE_DATES.map((date) => (
                    <button
                      key={date}
                      onClick={() => handleDateSelect(date)}
                      className={`
                        p-4 border rounded-lg text-center transition-colors
                        ${selectedDate === date 
                          ? 'bg-purple-600 text-white border-purple-600' 
                          : 'bg-white hover:bg-purple-50 border-gray-200'}
                      `}
                    >
                      <div className="text-sm">{new Date(date).toLocaleDateString('en-US', { month: 'short' })}</div>
                      <div className="text-xl font-bold">{new Date(date).getDate()}</div>
                      <div className="text-sm">{new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {step === 2 && (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold mb-2 flex items-center">
                  <User className="h-5 w-5 mr-2 text-purple-600" />
                  Select a Beautician
                </h2>
                <p className="text-gray-500 mb-6">
                  Available on {formatDate(selectedDate!)}
                </p>
                
                {availableBeauticians.length > 0 ? (
                  <div className="space-y-4">
                    {availableBeauticians.map((beautician) => (
                      <div key={beautician.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="p-4 flex flex-col sm:flex-row">
                          <div className="sm:w-1/4 mb-4 sm:mb-0">
                            <img
                              src={beautician.photo}
                              alt={beautician.name}
                              className="w-full h-40 sm:h-32 object-cover rounded-lg"
                            />
                          </div>
                          
                          <div className="sm:w-3/4 sm:pl-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="text-lg font-bold">{beautician.name}</h3>
                                <p className="text-purple-600">{beautician.specialization}</p>
                              </div>
                              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded">
                                <Star className="h-4 w-4 text-yellow-500 mr-1" fill="currentColor" />
                                <span className="font-medium">{beautician.rating}</span>
                              </div>
                            </div>
                            
                            <p className="text-gray-600 mt-1">Experience: {beautician.experience}</p>
                            
                            <div className="mt-4 flex flex-wrap gap-2">
                              {beautician.services.map((service) => (
                                <span key={service.id} className="bg-purple-50 text-purple-700 text-xs px-2 py-1 rounded">
                                  {service.name}
                                </span>
                              ))}
                            </div>
                            
                            <div className="mt-4 flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
                              <Button
                                onClick={() => handleBeauticianSelect(beautician)}
                                size="sm"
                              >
                                Select & Continue
                              </Button>
                              
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => togglePortfolio(beautician.id)}
                              >
                                {portfolioOpen === beautician.id ? (
                                  <>
                                    <ChevronUp className="h-4 w-4 mr-1" />
                                    Hide Portfolio
                                  </>
                                ) : (
                                  <>
                                    <ChevronDown className="h-4 w-4 mr-1" />
                                    View Portfolio
                                  </>
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>
                        
                        {portfolioOpen === beautician.id && (
                          <div className="p-4 bg-gray-50 border-t border-gray-200">
                            <h4 className="font-medium mb-3">Portfolio</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              {beautician.portfolio.map((image, index) => (
                                <img
                                  key={index}
                                  src={image}
                                  alt={`${beautician.name}'s work ${index + 1}`}
                                  className="w-full h-48 object-cover rounded"
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">No beauticians available on this date.</p>
                    <Button variant="outline" onClick={() => setStep(1)}>
                      Choose Another Date
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            {step === 3 && selectedBeautician && (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold mb-2 flex items-center">
                  <Gift className="h-5 w-5 mr-2 text-purple-600" />
                  Select a Service
                </h2>
                <p className="text-gray-500 mb-6">
                  Services offered by {selectedBeautician.name}
                </p>
                
                <div className="space-y-4">
                  {selectedBeautician.services.map((service) => (
                    <div
                      key={service.id}
                      onClick={() => handleServiceSelect(service)}
                      className={`
                        border rounded-lg p-4 flex flex-col sm:flex-row cursor-pointer transition-all
                        ${selectedService?.id === service.id 
                          ? 'border-purple-600 bg-purple-50' 
                          : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50'}
                      `}
                    >
                      <div className="sm:w-1/4 mb-4 sm:mb-0">
                        <img
                          src={service.image}
                          alt={service.name}
                          className="w-full h-40 sm:h-32 object-cover rounded-lg"
                        />
                      </div>
                      
                      <div className="sm:w-3/4 sm:pl-4">
                        <div className="flex justify-between items-start">
                          <h3 className="text-lg font-bold">{service.name}</h3>
                          <span className="font-bold text-purple-700">${service.price}</span>
                        </div>
                        
                        <p className="text-gray-600 mt-1">{service.description}</p>
                        
                        <div className="mt-3 flex items-center text-gray-600">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>{service.duration}</span>
                        </div>
                        
                        <div className="mt-4">
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleServiceSelect(service);
                            }}
                          >
                            Select This Service
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {step === 4 && selectedService && (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold mb-2 flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-purple-600" />
                  Select a Time
                </h2>
                <p className="text-gray-500 mb-6">
                  Available time slots on {formatDate(selectedDate!)}
                </p>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {TIME_SLOTS.map((time) => (
                    <button
                      key={time}
                      onClick={() => handleTimeSelect(time)}
                      className={`
                        p-3 border rounded-lg text-center transition-colors
                        ${selectedTime === time 
                          ? 'bg-purple-600 text-white border-purple-600' 
                          : 'bg-white hover:bg-purple-50 border-gray-200'}
                      `}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {step === 5 && selectedService && selectedTime && (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold mb-6 flex items-center">
                  <svg className="h-5 w-5 mr-2 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Confirm Your Appointment
                </h2>
                
                <div className="bg-gray-50 rounded-lg p-6 mb-6">
                  <div className="mb-4 pb-4 border-b border-gray-200">
                    <div className="text-sm text-gray-500">Date & Time</div>
                    <div className="font-medium">
                      {formatDate(selectedDate!)}, {selectedTime}
                    </div>
                  </div>
                  
                  <div className="mb-4 pb-4 border-b border-gray-200">
                    <div className="text-sm text-gray-500">Beautician</div>
                    <div className="font-medium">{selectedBeautician?.name}</div>
                    <div className="text-sm text-purple-600">{selectedBeautician?.specialization}</div>
                  </div>
                  
                  <div className="mb-4 pb-4 border-b border-gray-200">
                    <div className="text-sm text-gray-500">Service</div>
                    <div className="font-medium">{selectedService.name}</div>
                    <div className="text-sm">{selectedService.duration}</div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-500">Price</div>
                    <div className="text-xl font-bold text-purple-700">${selectedService.price.toFixed(2)}</div>
                  </div>
                </div>
                
                <div className="flex flex-col space-y-3">
                  <Button size="lg">
                    Confirm Appointment
                  </Button>
                  <Button variant="outline" size="lg" onClick={() => setStep(1)}>
                    Start Over
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

function User(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}