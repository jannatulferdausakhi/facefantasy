import React, { useState } from 'react';
import { Plus, Edit, Trash2, Search, CheckCircle, XCircle, Star, AlertCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Beautician } from '../../types';

// Mock beauticians data including pending applications
const MOCK_BEAUTICIANS: (Beautician & { status: 'approved' | 'pending' | 'rejected' })[] = [
  {
    id: '1',
    name: 'Emma Wilson',
    photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Makeup Artist',
    experience: '5 years',
    rating: 4.8,
    portfolio: [
      'https://images.pexels.com/photos/2681751/pexels-photo-2681751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2442898/pexels-photo-2442898.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3762423/pexels-photo-3762423.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '101', name: 'Bridal Makeup', description: 'Complete bridal makeup with touch-ups', price: 150, duration: '3 hours', image: 'https://images.pexels.com/photos/1741230/pexels-photo-1741230.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '102', name: 'Natural Everyday Look', description: 'Subtle makeup for daily wear', price: 65, duration: '45 minutes', image: 'https://images.pexels.com/photos/942317/pexels-photo-942317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-16', '2025-01-17', '2025-01-18', '2025-01-20'],
    status: 'approved'
  },
  {
    id: '2',
    name: 'Sophia Chen',
    photo: 'https://images.pexels.com/photos/3444087/pexels-photo-3444087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Skincare Specialist',
    experience: '7 years',
    rating: 4.9,
    portfolio: [
      'https://images.pexels.com/photos/3764013/pexels-photo-3764013.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3738353/pexels-photo-3738353.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3738352/pexels-photo-3738352.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '201', name: 'Deep Cleansing Facial', description: 'Thorough cleansing and extraction', price: 85, duration: '60 minutes', image: 'https://images.pexels.com/photos/3764012/pexels-photo-3764012.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '202', name: 'Anti-Aging Treatment', description: 'Premium facial with anti-aging benefits', price: 120, duration: '75 minutes', image: 'https://images.pexels.com/photos/3997387/pexels-photo-3997387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-16', '2025-01-19', '2025-01-20', '2025-01-21'],
    status: 'approved'
  },
  {
    id: '3',
    name: 'Olivia Martinez',
    photo: 'https://images.pexels.com/photos/1840608/pexels-photo-1840608.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Makeup & Hair Stylist',
    experience: '6 years',
    rating: 4.7,
    portfolio: [
      'https://images.pexels.com/photos/3097158/pexels-photo-3097158.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2816792/pexels-photo-2816792.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3810873/pexels-photo-3810873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '301', name: 'Makeup & Hair for Event', description: 'Full makeup and hairstyling', price: 110, duration: '90 minutes', image: 'https://images.pexels.com/photos/2811090/pexels-photo-2811090.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '302', name: 'Hair Styling Only', description: 'Professional hair styling', price: 50, duration: '45 minutes', image: 'https://images.pexels.com/photos/3993329/pexels-photo-3993329.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: ['2025-01-15', '2025-01-17', '2025-01-18', '2025-01-21', '2025-01-22'],
    status: 'approved'
  },
  {
    id: '4',
    name: 'Lisa Johnson',
    photo: 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Brow & Lash Specialist',
    experience: '3 years',
    rating: 0,
    portfolio: [
      'https://images.pexels.com/photos/3373716/pexels-photo-3373716.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '401', name: 'Brow Shaping', description: 'Professional brow shaping', price: 45, duration: '30 minutes', image: 'https://images.pexels.com/photos/3373716/pexels-photo-3373716.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '402', name: 'Lash Extensions', description: 'Full set of lash extensions', price: 120, duration: '120 minutes', image: 'https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: [],
    status: 'pending'
  },
  {
    id: '5',
    name: 'Natasha Kim',
    photo: 'https://images.pexels.com/photos/3762554/pexels-photo-3762554.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    specialization: 'Nail Artist',
    experience: '4 years',
    rating: 0,
    portfolio: [
      'https://images.pexels.com/photos/939836/pexels-photo-939836.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4210861/pexels-photo-4210861.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    services: [
      { id: '501', name: 'Gel Manicure', description: 'Long-lasting gel polish', price: 50, duration: '45 minutes', image: 'https://images.pexels.com/photos/939836/pexels-photo-939836.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
      { id: '502', name: 'Nail Art', description: 'Custom nail designs', price: 75, duration: '60 minutes', image: 'https://images.pexels.com/photos/4210861/pexels-photo-4210861.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    ],
    availability: [],
    status: 'pending'
  },
];

export const AdminBeauticiansPage: React.FC = () => {
  const [beauticians, setBeauticians] = useState(MOCK_BEAUTICIANS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'approved' | 'pending' | 'rejected'>('all');
  const [selectedBeautician, setSelectedBeautician] = useState<(Beautician & { status: string }) | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  // Filter beauticians based on search query and status
  const filteredBeauticians = beauticians.filter(beautician => {
    const matchesSearch = 
      beautician.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      beautician.specialization.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || beautician.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Handle approve beautician
  const handleApprove = (id: string) => {
    setBeauticians(beauticians.map(beautician => 
      beautician.id === id ? { ...beautician, status: 'approved' } : beautician
    ));
  };

  // Handle reject beautician
  const handleReject = (id: string) => {
    setBeauticians(beauticians.map(beautician => 
      beautician.id === id ? { ...beautician, status: 'rejected' } : beautician
    ));
  };

  // Get pending applications count
  const pendingCount = beauticians.filter(b => b.status === 'pending').length;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
              <div>
                <h1 className="text-2xl font-bold">Manage Beauticians</h1>
                {pendingCount > 0 && (
                  <p className="text-sm text-purple-600 mt-1">
                    {pendingCount} pending application{pendingCount !== 1 ? 's' : ''} to review
                  </p>
                )}
              </div>
              
              <div className="flex space-x-2 mt-4 sm:mt-0">
                <Button>
                  <Plus className="h-5 w-5 mr-1" />
                  Add Beautician
                </Button>
              </div>
            </div>
          </div>
          
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="md:w-1/2 relative">
                <input
                  type="text"
                  placeholder="Search beauticians..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
              
              <div className="md:w-1/2">
                <div className="flex rounded-md overflow-hidden">
                  <button
                    onClick={() => setStatusFilter('all')}
                    className={`flex-1 py-2 px-4 ${statusFilter === 'all' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setStatusFilter('approved')}
                    className={`flex-1 py-2 px-4 ${statusFilter === 'approved' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    Active
                  </button>
                  <button
                    onClick={() => setStatusFilter('pending')}
                    className={`flex-1 py-2 px-4 ${statusFilter === 'pending' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} relative`}
                  >
                    Pending
                    {pendingCount > 0 && (
                      <span className="absolute top-1 right-1 bg-red-500 text-white rounded-full h-5 w-5 flex items-center justify-center text-xs">
                        {pendingCount}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => setStatusFilter('rejected')}
                    className={`flex-1 py-2 px-4 ${statusFilter === 'rejected' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    Rejected
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 gap-6">
              {filteredBeauticians.map((beautician) => (
                <div
                  key={beautician.id}
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <div className="p-4 flex flex-col md:flex-row">
                    <div className="md:w-1/4 lg:w-1/6 mb-4 md:mb-0">
                      <img
                        src={beautician.photo}
                        alt={beautician.name}
                        className="w-full h-40 md:h-32 object-cover rounded-lg"
                      />
                    </div>
                    
                    <div className="md:w-3/4 lg:w-5/6 md:pl-4">
                      <div className="flex flex-wrap justify-between items-start gap-2">
                        <div>
                          <div className="flex items-center">
                            <h3 className="text-lg font-bold mr-2">{beautician.name}</h3>
                            {beautician.status === 'approved' && (
                              <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full flex items-center">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Active
                              </span>
                            )}
                            {beautician.status === 'pending' && (
                              <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full flex items-center">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Pending
                              </span>
                            )}
                            {beautician.status === 'rejected' && (
                              <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full flex items-center">
                                <XCircle className="h-3 w-3 mr-1" />
                                Rejected
                              </span>
                            )}
                          </div>
                          <p className="text-purple-600">{beautician.specialization}</p>
                        </div>
                        
                        {beautician.status === 'approved' && (
                          <div className="flex items-center bg-yellow-50 px-2 py-1 rounded">
                            <Star className="h-4 w-4 text-yellow-500 mr-1" fill="currentColor" />
                            <span className="font-medium">{beautician.rating}</span>
                          </div>
                        )}
                      </div>
                      
                      <p className="text-gray-600 mt-1">Experience: {beautician.experience}</p>
                      
                      {beautician.status === 'approved' && (
                        <div className="mt-2">
                          <p className="text-sm text-gray-500">Services:</p>
                          <div className="mt-1 flex flex-wrap gap-2">
                            {beautician.services.map((service) => (
                              <span key={service.id} className="bg-purple-50 text-purple-700 text-xs px-2 py-1 rounded">
                                {service.name} - ${service.price}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedBeautician(beautician);
                            setIsViewModalOpen(true);
                          }}
                        >
                          View Details
                        </Button>
                        
                        {beautician.status === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => handleApprove(beautician.id)}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => handleReject(beautician.id)}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </>
                        )}
                        
                        {beautician.status === 'approved' && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-red-500 text-red-500 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Deactivate
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredBeauticians.length === 0 && (
                <div className="text-center py-12">
                  <div className="h-20 w-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <Search className="h-10 w-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">No beauticians found</h3>
                  <p className="text-gray-500 mb-6">
                    We couldn't find any beauticians matching your search criteria.
                  </p>
                  <Button onClick={() => { setSearchQuery(''); setStatusFilter('all'); }}>
                    Clear Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* View Beautician Details Modal */}
      {isViewModalOpen && selectedBeautician && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-4xl w-full my-8">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-xl font-bold">Beautician Details</h2>
              <button
                onClick={() => setIsViewModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/3">
                  <img
                    src={selectedBeautician.photo}
                    alt={selectedBeautician.name}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  
                  <div className="mt-4">
                    <h3 className="font-bold text-lg">{selectedBeautician.name}</h3>
                    <p className="text-purple-600">{selectedBeautician.specialization}</p>
                    
                    <div className="mt-2 space-y-1">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Status:</span>
                        <span className={`
                          ${selectedBeautician.status === 'approved' ? 'text-green-600' : ''}
                          ${selectedBeautician.status === 'pending' ? 'text-yellow-600' : ''}
                          ${selectedBeautician.status === 'rejected' ? 'text-red-600' : ''}
                          font-medium
                        `}>
                          {selectedBeautician.status.charAt(0).toUpperCase() + selectedBeautician.status.slice(1)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Experience:</span>
                        <span className="font-medium">{selectedBeautician.experience}</span>
                      </div>
                      {selectedBeautician.status === 'approved' && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Rating:</span>
                          <span className="font-medium flex items-center">
                            {selectedBeautician.rating}
                            <Star className="h-4 w-4 text-yellow-500 ml-1" fill="currentColor" />
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {selectedBeautician.status === 'pending' && (
                    <div className="mt-6 space-y-2">
                      <Button
                        fullWidth
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => {
                          handleApprove(selectedBeautician.id);
                          setIsViewModalOpen(false);
                        }}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve Application
                      </Button>
                      <Button
                        fullWidth
                        className="bg-red-600 hover:bg-red-700"
                        onClick={() => {
                          handleReject(selectedBeautician.id);
                          setIsViewModalOpen(false);
                        }}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject Application
                      </Button>
                    </div>
                  )}
                </div>
                
                <div className="md:w-2/3">
                  <div className="mb-6">
                    <h4 className="font-bold mb-2">Portfolio</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {selectedBeautician.portfolio.map((image, index) => (
                        <img
                          key={index}
                          src={image}
                          alt={`${selectedBeautician.name}'s work ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="font-bold mb-2">Services</h4>
                    <div className="space-y-4">
                      {selectedBeautician.services.map((service) => (
                        <div key={service.id} className="border border-gray-200 rounded-lg p-3 flex gap-3">
                          <div className="w-20 h-20 rounded-lg overflow-hidden">
                            <img
                              src={service.image}
                              alt={service.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <h5 className="font-medium">{service.name}</h5>
                              <span className="font-bold text-purple-700">${service.price}</span>
                            </div>
                            <p className="text-sm text-gray-600">{service.description}</p>
                            <div className="mt-1 text-xs text-gray-500">Duration: {service.duration}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {selectedBeautician.status === 'approved' && selectedBeautician.availability.length > 0 && (
                    <div>
                      <h4 className="font-bold mb-2">Availability</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedBeautician.availability.map((date) => (
                          <span key={date} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                            {new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};