import React, { useState } from 'react';
import { Search, BookOpen, Tag, Calendar, ArrowRight, Clock } from 'lucide-react';
import { SkincareTip } from '../../types';

// Mock skincare tips data
const MOCK_SKINCARE_TIPS: SkincareTip[] = [
  {
    id: '1',
    title: 'The Importance of Sunscreen in Your Daily Routine',
    content: `
      <p>Sunscreen is the most crucial step in any skincare routine, regardless of skin tone or weather conditions. Here's why:</p>
      
      <h4>Prevents Premature Aging</h4>
      <p>UV rays are responsible for up to 90% of visible signs of aging, including wrinkles, fine lines, and loss of elasticity. Daily sunscreen use can significantly slow this process.</p>
      
      <h4>Reduces Hyperpigmentation Risk</h4>
      <p>Sunscreen helps prevent dark spots and uneven skin tone by blocking the UV rays that trigger excess melanin production.</p>
      
      <h4>How to Apply</h4>
      <p>Apply a broad-spectrum SPF 30+ sunscreen as the final step of your morning skincare routine. Use approximately a quarter-sized amount for your face and reapply every two hours when outdoors.</p>
      
      <h4>Best Sunscreen Types by Skin Type</h4>
      <ul>
        <li><strong>Oily skin:</strong> Look for oil-free, non-comedogenic gel formulations</li>
        <li><strong>Dry skin:</strong> Choose moisturizing creams with added hydrating ingredients</li>
        <li><strong>Sensitive skin:</strong> Opt for mineral (physical) sunscreens with zinc oxide or titanium dioxide</li>
      </ul>
    `,
    image: 'https://images.pexels.com/photos/3762878/pexels-photo-3762878.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Basics'
  },
  {
    id: '2',
    title: 'Understanding Your Skin Type for Better Results',
    content: `
      <p>Knowing your skin type is essential for creating an effective skincare routine. Different skin types require different approaches:</p>
      
      <h4>How to Determine Your Skin Type</h4>
      <p>Wash your face with a gentle cleanser, pat dry, and wait 30 minutes without applying any products. Then:</p>
      <ul>
        <li><strong>Normal skin:</strong> Feels comfortable, neither oily nor dry</li>
        <li><strong>Oily skin:</strong> Appears shiny, especially in the T-zone</li>
        <li><strong>Dry skin:</strong> Feels tight and may show flakiness</li>
        <li><strong>Combination skin:</strong> Oily in T-zone but normal to dry elsewhere</li>
        <li><strong>Sensitive skin:</strong> Easily becomes irritated, red, or inflamed</li>
      </ul>
      
      <h4>Caring for Different Skin Types</h4>
      <p><strong>For oily skin:</strong> Use foaming cleansers, lightweight hydrators, and oil-controlling products containing ingredients like niacinamide, salicylic acid, and clay masks.</p>
      
      <p><strong>For dry skin:</strong> Focus on cream cleansers, rich moisturizers, and hydrating ingredients like hyaluronic acid, glycerin, and ceramides.</p>
      
      <p><strong>For combination skin:</strong> Consider multi-masking or using different products on different areas of your face.</p>
      
      <p><strong>For sensitive skin:</strong> Choose fragrance-free products with minimal ingredients and always patch test new products.</p>
    `,
    image: 'https://images.pexels.com/photos/3864470/pexels-photo-3864470.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Basics'
  },
  {
    id: '3',
    title: 'The Right Order to Apply Skincare Products',
    content: `
      <p>The sequence of applying skincare products matters significantly for optimal effectiveness. Follow this guide:</p>
      
      <h4>Morning Routine</h4>
      <ol>
        <li><strong>Cleanser:</strong> Start with clean skin</li>
        <li><strong>Toner:</strong> Balance pH and prepare skin (if used)</li>
        <li><strong>Treatments:</strong> Apply serums (Vitamin C is excellent for mornings)</li>
        <li><strong>Eye cream:</strong> Target the delicate eye area</li>
        <li><strong>Moisturizer:</strong> Lock in hydration</li>
        <li><strong>Sunscreen:</strong> Protect from UV damage</li>
      </ol>
      
      <h4>Evening Routine</h4>
      <ol>
        <li><strong>Makeup remover:</strong> For makeup wearers</li>
        <li><strong>Cleanser:</strong> Remove impurities from the day</li>
        <li><strong>Exfoliant:</strong> 2-3 times weekly</li>
        <li><strong>Toner:</strong> Hydrate and prep skin</li>
        <li><strong>Treatments:</strong> Apply more intensive treatments (retinoids, acids)</li>
        <li><strong>Eye cream:</strong> Nourish eye area</li>
        <li><strong>Moisturizer/Night cream:</strong> Seal in treatments and hydrate</li>
        <li><strong>Face oil:</strong> For extra nourishment if needed</li>
      </ol>
      
      <h4>Key Tips</h4>
      <ul>
        <li>Apply products from thinnest to thickest consistency</li>
        <li>Wait 1-2 minutes between layers for better absorption</li>
        <li>Don't mix certain actives (e.g., retinol and vitamin C) unless instructed by a dermatologist</li>
      </ul>
    `,
    image: 'https://images.pexels.com/photos/3736398/pexels-photo-3736398.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'How-to'
  },
  {
    id: '4',
    title: 'How to Effectively Treat Acne',
    content: `
      <p>Acne affects people of all ages and can be managed with the right approach:</p>
      
      <h4>Key Acne-Fighting Ingredients</h4>
      <ul>
        <li><strong>Salicylic Acid:</strong> Penetrates pores to remove excess oil and dead skin cells</li>
        <li><strong>Benzoyl Peroxide:</strong> Kills acne-causing bacteria</li>
        <li><strong>Retinoids:</strong> Accelerate cell turnover and prevent clogged pores</li>
        <li><strong>Niacinamide:</strong> Reduces inflammation and regulates oil production</li>
      </ul>
      
      <h4>Essential Steps for Acne-Prone Skin</h4>
      <ol>
        <li>Use a gentle, non-stripping cleanser twice daily</li>
        <li>Apply spot treatments only on active breakouts</li>
        <li>Never skip moisturizer (use oil-free formulations)</li>
        <li>Always use sunscreen (many acne treatments increase sun sensitivity)</li>
        <li>Change pillowcases 1-2 times weekly</li>
        <li>Don't pick or pop pimples</li>
      </ol>
      
      <h4>When to See a Dermatologist</h4>
      <p>Consider consulting a professional if:</p>
      <ul>
        <li>Over-the-counter treatments aren't helping after 8-12 weeks</li>
        <li>Your acne is severe or causing scarring</li>
        <li>You experience painful, deep cysts</li>
        <li>Acne is affecting your self-esteem or quality of life</li>
      </ul>
    `,
    image: 'https://images.pexels.com/photos/3764013/pexels-photo-3764013.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Concerns'
  },
  {
    id: '5',
    title: 'Anti-Aging Skincare: Prevention and Treatment',
    content: `
      <p>The best anti-aging strategy combines preventive measures with targeted treatments:</p>
      
      <h4>Preventive Measures</h4>
      <ul>
        <li><strong>Sun protection:</strong> Daily broad-spectrum SPF 30+ sunscreen is non-negotiable</li>
        <li><strong>Antioxidants:</strong> Use products with vitamins C and E to fight free radical damage</li>
        <li><strong>Hydration:</strong> Keep skin plump with humectants like hyaluronic acid</li>
        <li><strong>Lifestyle factors:</strong> Adequate sleep, balanced diet, and stress management</li>
      </ul>
      
      <h4>Best Anti-Aging Ingredients</h4>
      <ul>
        <li><strong>Retinoids:</strong> Gold standard for stimulating collagen and accelerating cell turnover</li>
        <li><strong>Peptides:</strong> Signal skin to produce more collagen</li>
        <li><strong>AHAs/BHAs:</strong> Exfoliate to reveal fresher skin and improve product penetration</li>
        <li><strong>Niacinamide:</strong> Supports skin barrier and improves elasticity</li>
        <li><strong>Bakuchiol:</strong> A gentler, plant-based alternative to retinol</li>
      </ul>
      
      <h4>Anti-Aging by Decade</h4>
      <p><strong>20s:</strong> Focus on prevention with SPF, antioxidants, and hydration</p>
      <p><strong>30s:</strong> Add retinol and eye cream, consider professional treatments</p>
      <p><strong>40s+:</strong> Increase concentration of active ingredients, target specific concerns</p>
      
      <h4>Professional Treatments</h4>
      <p>Consider treatments like chemical peels, microneedling, or laser therapy for more significant results, especially for mature skin.</p>
    `,
    image: 'https://images.pexels.com/photos/3762876/pexels-photo-3762876.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Concerns'
  },
  {
    id: '6',
    title: 'Seasonal Skincare Adjustments',
    content: `
      <p>Your skin's needs change with the seasons, requiring adjustments to your routine:</p>
      
      <h4>Summer Skincare</h4>
      <ul>
        <li>Switch to lighter moisturizers and gel-based formulas</li>
        <li>Increase sunscreen application and reapplication</li>
        <li>Consider adding vitamin C for enhanced UV protection</li>
        <li>Use oil-controlling products if needed</li>
        <li>Incorporate gentle exfoliation to prevent clogged pores</li>
      </ul>
      
      <h4>Winter Skincare</h4>
      <ul>
        <li>Use richer, more occlusive moisturizers</li>
        <li>Add a hydrating serum with hyaluronic acid</li>
        <li>Consider facial oils for extra nourishment</li>
        <li>Reduce exfoliation frequency to avoid irritation</li>
        <li>Don't forget sunscreen even on cloudy days</li>
        <li>Use a humidifier indoors to combat dry air</li>
      </ul>
      
      <h4>Transitional Seasons</h4>
      <p>Spring and fall are perfect times to:</p>
      <ul>
        <li>Assess your skin's changing needs</li>
        <li>Gradually adjust product consistency</li>
        <li>Address any seasonal allergies that might affect skin</li>
        <li>Repair summer damage or prepare for winter dryness</li>
      </ul>
    `,
    image: 'https://images.pexels.com/photos/3762879/pexels-photo-3762879.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Seasonal'
  },
];

export const SkincareTipsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedTip, setExpandedTip] = useState<string | null>(null);
  
  // Extract unique categories
  const categories = Array.from(new Set(MOCK_SKINCARE_TIPS.map(tip => tip.category)));
  
  // Filter tips based on search query and selected category
  const filteredTips = MOCK_SKINCARE_TIPS.filter(tip => {
    const matchesSearch = tip.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || tip.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-4">Skincare Tips & Guides</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover expert advice and helpful guides to enhance your skincare routine and 
            achieve your best skin ever.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          <div className="w-full md:w-2/3 relative">
            <input
              type="text"
              placeholder="Search for skincare tips..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          </div>
          
          <div className="w-full md:w-1/3">
            <select
              value={selectedCategory || ''}
              onChange={(e) => setSelectedCategory(e.target.value || null)}
              className="w-full py-3 px-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 appearance-none bg-white"
              style={{ 
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 1rem center',
                backgroundSize: '1rem'
              }}
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
        </div>
        
        {filteredTips.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTips.map((tip) => (
              <div
                key={tip.id}
                className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={tip.image}
                    alt={tip.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-0 left-0 bg-purple-600 text-white text-xs px-3 py-1">
                    {tip.category}
                  </div>
                </div>
                
                <div className="p-6">
                  <h2 className="text-xl font-bold mb-4">{tip.title}</h2>
                  
                  {expandedTip === tip.id ? (
                    <div 
                      className="prose prose-sm max-w-none"
                      dangerouslySetInnerHTML={{ __html: tip.content }} 
                    />
                  ) : (
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {tip.content.replace(/<[^>]*>?/gm, '').substring(0, 150)}...
                    </p>
                  )}
                  
                  <div className="mt-4 flex justify-between items-center">
                    <span className="flex items-center text-gray-500 text-sm">
                      <Clock className="h-4 w-4 mr-1" />
                      {(tip.content.length / 1000).toFixed(0)} min read
                    </span>
                    
                    <button
                      onClick={() => setExpandedTip(expandedTip === tip.id ? null : tip.id)}
                      className="flex items-center text-purple-600 hover:text-purple-700"
                    >
                      {expandedTip === tip.id ? 'Read Less' : 'Read More'}
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl p-12 text-center">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">No tips found</h3>
            <p className="text-gray-600 mb-4">
              We couldn't find any skincare tips matching your search criteria.
            </p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedCategory(null); }}
              className="text-purple-600 hover:text-purple-700 font-medium"
            >
              Clear filters
            </button>
          </div>
        )}
        
        {/* Category Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(
                  selectedCategory === category ? null : category
                )}
                className={`
                  p-6 rounded-lg text-center transition-all
                  ${selectedCategory === category 
                    ? 'bg-purple-600 text-white' 
                    : 'bg-white hover:bg-purple-50 text-gray-700'}
                `}
              >
                <Tag className={`h-6 w-6 mx-auto mb-2 ${selectedCategory === category ? 'text-white' : 'text-purple-600'}`} />
                <span className="font-medium">{category}</span>
              </button>
            ))}
          </div>
        </div>
        
        {/* Subscribe Section */}
        <div className="mt-16 bg-gradient-to-r from-purple-600 to-pink-500 rounded-xl p-8 text-white">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h3 className="text-2xl font-bold mb-2">Get Skincare Tips in Your Inbox</h3>
              <p className="text-purple-100">
                Subscribe to our newsletter for weekly skincare tips, product recommendations, and exclusive offers.
              </p>
            </div>
            
            <div className="md:w-1/3 w-full">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="flex-1 p-3 rounded-l-lg focus:outline-none text-gray-700"
                />
                <button className="bg-purple-900 hover:bg-purple-800 text-white px-4 py-3 rounded-r-lg font-medium">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};