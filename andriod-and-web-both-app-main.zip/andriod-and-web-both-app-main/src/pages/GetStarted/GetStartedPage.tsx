import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Camera, Users } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export const GetStartedPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero section */}
      <div 
        className="bg-cover bg-center bg-no-repeat py-20 px-4 text-white relative"
        style={{ 
          backgroundImage: 'linear-gradient(rgba(126, 34, 206, 0.8), rgba(192, 38, 211, 0.7)), url(https://images.pexels.com/photos/2681751/pexels-photo-2681751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)' 
        }}
      >
        <div className="absolute inset-0 bg-black opacity-30" />
        
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
            Discover Your Perfect Look
          </h1>
          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
            Elevate your beauty journey with professional guidance and cutting-edge tools.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/signup">
              <Button size="lg">
                Get Started
              </Button>
            </Link>
            <Link to="/login">
              <Button variant="outline" size="lg" className="bg-white bg-opacity-20 hover:bg-opacity-30">
                I Already Have an Account
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Features section */}
      <div className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose YourFaceFantasy</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-purple-50 rounded-xl p-8 transition-transform duration-300 hover:scale-105 hover:shadow-md">
              <div className="h-14 w-14 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-4">
                <Sparkles className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Instant Try-On</h3>
              <p className="text-gray-600">
                Experience makeup virtually before you commit. Our advanced technology lets you try on makeup instantly.
              </p>
            </div>
            
            {/* Feature 2 */}
            <div className="bg-pink-50 rounded-xl p-8 transition-transform duration-300 hover:scale-105 hover:shadow-md">
              <div className="h-14 w-14 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center mb-4">
                <Camera className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Perfect Selfies</h3>
              <p className="text-gray-600">
                Capture your best self with our optimized camera features designed specifically for makeup selfies.
              </p>
            </div>
            
            {/* Feature 3 */}
            <div className="bg-purple-50 rounded-xl p-8 transition-transform duration-300 hover:scale-105 hover:shadow-md">
              <div className="h-14 w-14 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-4">
                <Users className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Community</h3>
              <p className="text-gray-600">
                Join our vibrant community of beauty enthusiasts. Share your looks, get inspired, and learn from each other.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonial section */}
      <div className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-purple-200 flex items-center justify-center mr-4 overflow-hidden">
                  <img src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="User" className="h-full w-full object-cover" />
                </div>
                <div>
                  <h4 className="font-bold">Sarah Johnson</h4>
                  <p className="text-sm text-gray-500">Beauty Enthusiast</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "This app completely transformed my makeup routine! The virtual try-on is so realistic,
                and the beauty tips helped me find the perfect look for my skin tone."
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-purple-200 flex items-center justify-center mr-4 overflow-hidden">
                  <img src="https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="User" className="h-full w-full object-cover" />
                </div>
                <div>
                  <h4 className="font-bold">Michelle Lee</h4>
                  <p className="text-sm text-gray-500">Makeup Artist</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "As a professional, I recommend YourFaceFantasy to all my clients. The appointment booking
                system is seamless, and the product recommendations are always spot-on."
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA section */}
      <div className="py-16 px-4 bg-purple-600 text-white text-center">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Beauty Journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of women who've discovered their perfect look with YourFaceFantasy.
          </p>
          <Link to="/signup">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
              Get Started Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};