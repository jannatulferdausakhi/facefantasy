import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { GetStartedPage } from './pages/GetStarted/GetStartedPage';
import { LoginPage } from './pages/Auth/LoginPage';
import { SignupPage } from './pages/Auth/SignupPage';
import { HomePage } from './pages/Home/HomePage';
import { AppointmentPage } from './pages/Appointment/AppointmentPage';
import { SkincareTipsPage } from './pages/SkincareTips/SkincareTipsPage';
import { AdminProductsPage } from './pages/Admin/AdminProductsPage';
import { AdminBeauticiansPage } from './pages/Admin/AdminBeauticiansPage';
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Protected route component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
};

// Admin route component
const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAdmin, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  
  if (!isAdmin) {
    return <Navigate to="/" />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          {/* Public routes */}
          <Route path="/get-started" element={<GetStartedPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          
          {/* Authenticated routes */}
          <Route element={<AppLayout />}>
            <Route path="/" element={
              <ProtectedRoute>
                <HomePage />
              </ProtectedRoute>
            } />
            <Route path="/appointments" element={
              <ProtectedRoute>
                <AppointmentPage />
              </ProtectedRoute>
            } />
            <Route path="/skincare-tips" element={
              <ProtectedRoute>
                <SkincareTipsPage />
              </ProtectedRoute>
            } />
            
            {/* Admin routes */}
            <Route path="/admin/products" element={
              <AdminRoute>
                <AdminProductsPage />
              </AdminRoute>
            } />
            <Route path="/admin/beauticians" element={
              <AdminRoute>
                <AdminBeauticiansPage />
              </AdminRoute>
            } />
          </Route>
          
          {/* Redirect to get-started page by default */}
          <Route path="*" element={<Navigate to="/get-started" />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;