export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin' | 'beautician';
  avatar?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

export interface Beautician {
  id: string;
  name: string;
  photo: string;
  specialization: string;
  experience: string;
  rating: number;
  portfolio: string[];
  services: Service[];
  availability: string[];
}

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  image: string;
}

export interface Appointment {
  id: string;
  userId: string;
  beauticianId: string;
  serviceId: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
}

export interface SkincareTip {
  id: string;
  title: string;
  content: string;
  image: string;
  category: string;
}