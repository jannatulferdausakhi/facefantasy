package com.yourfacefantasy.ui.getstarted;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.yourfacefantasy.databinding.ActivityGetStartedBinding;
import com.yourfacefantasy.ui.auth.LoginActivity;
import com.yourfacefantasy.ui.auth.SignupActivity;

public class GetStartedActivity extends AppCompatActivity {
    private ActivityGetStartedBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGetStartedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupClickListeners();
    }

    private void setupClickListeners() {
        binding.btnGetStarted.setOnClickListener(v -> 
            startActivity(new Intent(this, SignupActivity.class)));

        binding.btnLogin.setOnClickListener(v -> 
            startActivity(new Intent(this, LoginActivity.class)));
    }
}