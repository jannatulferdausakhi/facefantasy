# andriod-and-web-both-app

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/kamrulgoldar/andriod-and-web-both-app)